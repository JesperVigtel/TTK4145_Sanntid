package types

import . "elevator/internal/config"

type ConvergedSystemState struct {
	AliveList    [NElevators]bool
	ElevatorList [NElevators]HRAElevState
	OrderTables  [NElevators]OrderTable
}

type LocalSystemState struct {
	ElevatorID    int
	ElevatorState HRAElevState
	OrderStates   OrderTable
}

type Message struct {
	SenderID      int
	ElevatorState HRAElevState
	OrderTables   [NElevators]OrderTable
}

type MotorDirection int

const (
	Down MotorDirection = iota - 1
	Stop
	Up
)

type Elevator struct {
	CurrentFloor           int
	CurrentTravelDirection MotorDirection
	PhysicalMotorDirection MotorDirection
	AssignedOrders         AssignedOrderTable
	Behaviour              ElevatorBehaviour
	ActiveStatus           bool
}

type CompletedOrderTable [NFloors][NButtons]bool

type ButtonType int

const (
	BtnHallUp ButtonType = iota
	BtnHallDown
	BtnCab
)

type ElevatorBehaviour int

const (
	ElevatorIdle ElevatorBehaviour = iota
	ElevatorMoving
	ElevatorDoorOpen
)

type ButtonEvent struct {
	Floor  int
	Button ButtonType
}

type ElevatorEvents struct {
	Elevator        Elevator
	CompletedOrders CompletedOrderTable
	NewButtonPress  *ButtonEvent
	Obstructed      bool
}

type GlobalNodeRegistry struct {
	Nodes []int
	New   []int
	Lost  []int
}

type OrderState int

const (
	OrderStandby OrderState = iota
	OrderPending
	OrderAssigned
	OrderComplete
)

type OrderTable [NFloors][NButtons]OrderState
type AssignedOrderTable [NFloors][NButtons]bool
type HallLampTable [NFloors][2]bool

type HRAElevState struct {
	Behavior   string `json:"behaviour"`
	Floor      int    `json:"floor"`
	Direction  string `json:"direction"`
	Assignable bool   `json:"assignable"`
}

func NewHRAElevState(elev Elevator, assignable bool) HRAElevState {
	return HRAElevState{
		Behavior:   elevBehaviorToString(elev.Behaviour),
		Floor:      elev.CurrentFloor,
		Direction:  elevDirectionToString(elev.PhysicalMotorDirection),
		Assignable: assignable,
	}
}

type HRAAssignerState struct {
	Behavior    string `json:"behaviour"`
	Floor       int    `json:"floor"`
	Direction   string `json:"direction"`
	CabRequests []bool `json:"cabRequests"`
}

func NewHRAAssignerState(elevState HRAElevState, orders OrderTable) HRAAssignerState {
	return HRAAssignerState{
		Behavior:    elevState.Behavior,
		Floor:       elevState.Floor,
		Direction:   elevState.Direction,
		CabRequests: CabRequestsFromOrderTable(orders),
	}
}

func CabRequestsFromOrderTable(orderTable OrderTable) []bool {
	requests := make([]bool, NFloors)
	for floor := range NFloors {
		requests[floor] = IsActiveOrder(orderTable[floor][BtnCab])
	}
	return requests
}

func IsActiveOrder(orderState OrderState) bool {
	return orderState == OrderPending || orderState == OrderAssigned
}

func elevBehaviorToString(b ElevatorBehaviour) string {
	switch b {
	case ElevatorIdle:
		return "idle"
	case ElevatorMoving:
		return "moving"
	case ElevatorDoorOpen:
		return "doorOpen"
	default:
		return "idle"
	}
}

func elevDirectionToString(d MotorDirection) string {
	switch d {
	case Up:
		return "up"
	case Down:
		return "down"
	default:
		return "stop"
	}
}

type HRAInput struct {
	HallRequests [NFloors][2]bool            `json:"hallRequests"`
	States       map[string]HRAAssignerState `json:"states"`
}
